@echo off
setlocal EnableDelayedExpansion

:: ================================================
::  FRAME REPUBLIC  PC Optimizer  v3.0
::  Installez et lancez simplement
:: ================================================

title Frame Republic - Installation

:: Check if already admin
net session >nul 2>&1
if %errorlevel% equ 0 goto :isadmin

:: Re-launch as admin - simplest reliable method
echo Demande des droits administrateur...
powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
exit /b

:isadmin
cls
echo.
echo   ================================================
echo    FRAME REPUBLIC  ^|  PC Optimizer  v3.0
echo   ================================================
echo.
echo   Admin : OK

:: Get current directory - this is where the bat file is
cd /d "%~dp0"
set "MYDIR=%CD%"

echo   Dossier : %MYDIR%
echo.

set "PYFILE=%MYDIR%\frame_republic.py"
set "EXEFILE=%MYDIR%\FrameRepublic.exe"

echo   Verification des fichiers...
echo   Cherche : %PYFILE%

if not exist "%PYFILE%" (
    echo.
    echo   ERREUR: frame_republic.py introuvable dans :
    echo   %MYDIR%
    echo.
    echo   Solution: Mettez tous les fichiers dans le meme dossier.
    echo.
    pause
    exit /b 1
)
echo   frame_republic.py : OK

:: Find Python
echo.
echo   [1/4] Recherche Python 3...
set "PY="

for /f "delims=" %%P in ('where python.exe 2^>nul') do (
    if "!PY!"=="" (
        "%%P" -c "import sys; exit(0 if sys.version_info>=(3,8) else 1)" >nul 2>&1
        if !errorlevel! equ 0 set "PY=%%P"
    )
)

if "!PY!"=="" (
    where py.exe >nul 2>&1
    if !errorlevel! equ 0 (
        for /f "delims=" %%P in ('py.exe -3 -c "import sys; print(sys.executable)" 2^>nul') do (
            if "!PY!"=="" set "PY=%%P"
        )
    )
)

if "!PY!"=="" (
    for %%P in (
        "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
        "%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
        "%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
        "%LOCALAPPDATA%\Programs\Python\Python39\python.exe"
        "C:\Python312\python.exe"
        "C:\Python311\python.exe"
        "C:\Python310\python.exe"
        "%PROGRAMFILES%\Python312\python.exe"
        "%PROGRAMFILES%\Python311\python.exe"
    ) do (
        if "!PY!"=="" if exist %%P set "PY=%%~P"
    )
)

if "!PY!"=="" (
    echo   Python non trouve. Installation via winget...
    winget install --id Python.Python.3.12 --silent --accept-source-agreements --accept-package-agreements
    timeout /t 6 /nobreak >nul
    if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
        set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    ) else (
        for /f "delims=" %%P in ('where python.exe 2^>nul') do (
            if "!PY!"=="" set "PY=%%P"
        )
    )
)

if "!PY!"=="" (
    echo.
    echo   ERREUR: Python introuvable.
    echo   Installez Python 3.12 depuis: https://www.python.org/downloads/
    echo   Cochez "Add Python to PATH" lors de l'installation.
    echo   Relancez ensuite INSTALLER.bat
    pause
    exit /b 1
)

echo   Python : !PY!
"!PY!" --version

:: psutil
echo.
echo   [2/4] Installation psutil...
"!PY!" -m pip install psutil --quiet --disable-pip-version-check
"!PY!" -c "import psutil; print('  psutil', psutil.__version__, ': OK')"

:: Compile
echo.
if exist "%EXEFILE%" (
    echo   [3/4] FrameRepublic.exe deja present.
    goto :run
)

echo   [3/4] Compilation FrameRepublic.exe...
echo   (30-90 secondes - premiere installation uniquement)
echo.

"!PY!" -m pip install pyinstaller --quiet --disable-pip-version-check

set "BD=%TEMP%\fr_%RANDOM%"
mkdir "!BD!" >nul 2>&1

"!PY!" -m PyInstaller ^
    --onefile ^
    --windowed ^
    --name FrameRepublic ^
    --uac-admin ^
    --hidden-import psutil ^
    --hidden-import winreg ^
    --hidden-import urllib.request ^
    --hidden-import urllib.error ^
    --hidden-import json ^
    --hidden-import threading ^
    --hidden-import collections ^
    --hidden-import math ^
    --hidden-import shutil ^
    --hidden-import glob ^
    --hidden-import tempfile ^
    --collect-submodules psutil ^
    --distpath "%MYDIR%" ^
    --workpath "!BD!" ^
    --specpath "!BD!" ^
    --noconfirm ^
    "%PYFILE%"

if exist "!BD!" rmdir /s /q "!BD!" >nul 2>&1

if exist "%EXEFILE%" (
    echo.
    echo   FrameRepublic.exe cree avec succes !
) else (
    echo.
    echo   Compilation echouee - lancement Python direct.
)

:run
echo.
echo   [4/4] Lancement Frame Republic...
echo.
echo   Prochaine fois: double-clic sur FrameRepublic.exe
echo.

if exist "%EXEFILE%" (
    "%EXEFILE%"
) else (
    "!PY!" "%PYFILE%"
)

exit /b 0
